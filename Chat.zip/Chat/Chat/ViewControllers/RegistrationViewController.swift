import UIKit
import Firebase

class RegistrationViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var RegistrationButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        RegistrationButton.layer.cornerRadius = 8
        RegistrationButton.layer.masksToBounds = true
        
    }
    
    @IBAction func RegistrationButtonPressed(_ sender: Any) {
        guard let email = emailTextField.text else { return }
        guard let password = passwordTextField.text else { return }
        
        
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            if error != nil {
                 print("User no create ", error)
            }else{
                print("User create")
                self.performSegue(withIdentifier: "registrationToChat", sender: self)
            }
        }
    }
    
}
