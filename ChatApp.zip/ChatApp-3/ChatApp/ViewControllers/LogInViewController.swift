import UIKit
import Firebase

class LogInViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        logInButton.layer.cornerRadius = 8
        logInButton.layer.masksToBounds = true
    }
    @IBAction func logInButtonPressed(_ sender: Any) {
        guard let mail = emailTextField.text else { return }
        guard let passw = passwordTextField.text else { return }
        
        Auth.auth().signIn(withEmail: mail, password: passw) { (result, error) in
            if error != nil {
                 print("Couldn't log in ", error)
            }else{
                print("User logged in")
                self.performSegue(withIdentifier: "logInToChat", sender: self)
            }
        }
    }
    


}
