import UIKit
import Firebase

class ChatViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    private var messagesArray: [MessageEntity] = []

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    @IBOutlet weak var sendImageButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(moveBackInputTextField))
        tableView.addGestureRecognizer(tapGesture)
        tableView.register(UINib(nibName: MessageCell.identifier, bundle: Bundle.main), forCellReuseIdentifier: MessageCell.identifier)
        tableView.separatorStyle = .none
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 120
        
        inputTextField.delegate = self
        
        sendButton.layer.cornerRadius = 8
        sendButton.layer.masksToBounds = true
        
        retrievMessages()

    }
    
    @IBAction func logOutButtonPressed(_ sender: Any) {
        do{
            try Auth.auth().signOut()
            print("Logged Out Succesfully")
            navigationController?.popToRootViewController(animated: true)
        }catch{
            print(error)
        }
        
    }
    
    @IBAction func sendButtonPressed(_ sender: Any) {
        sendButton.isEnabled = false
        
        
        let messagesDb = Database.database().reference().child("Messages")
        
        guard let email = Auth.auth().currentUser?.email else { return }
        guard let message = inputTextField.text else { return }
        
        let messagesDict: [String : String ] = ["sender" : email, "message" : message]
        
        messagesDb.childByAutoId().setValue(messagesDict) { (error, reference) in
            if error != nil{
                print (error!)
            }else{
                self.sendButton.isEnabled = true
                self.inputTextField.text = ""
            }
            
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func moveBackInputTextField(){
        inputTextField.endEditing(true)
    }
    
    func retrievMessages(){
        let messagesDb = Database.database().reference().child("Messages")
        
        messagesDb.observe(.childAdded) { (snapshot) in
            let snapshotValue = snapshot.value as? [String : String]
            guard let sender = snapshotValue?["sender"] else { return }
            guard let message = snapshotValue?["message"] else { return }
            
            self.messagesArray.append(MessageEntity(sender: sender,message: message))
            self.tableView.reloadData()
            self.scrollToLastMessage()
        }
    }
    
    func scrollToLastMessage(){
        let indexPath = IndexPath(row: messagesArray.count - 1, section: 0)
        tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
    }
}


extension ChatViewController: UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.2) {
            self.heightConstraint.constant = 50 + 320
            self.view.layoutIfNeeded()
        }
        self.scrollToLastMessage()
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.2) {
            self.heightConstraint.constant = 50
            self.view.layoutIfNeeded()
        }
        self.scrollToLastMessage()
    }
    
}

extension ChatViewController: UITableViewDelegate{
    
}
extension ChatViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messagesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let mCell = tableView.dequeueReusableCell(withIdentifier: MessageCell.identifier, for: indexPath) as! MessageCell
        
        let message = messagesArray[indexPath.row]
        if Auth.auth().currentUser?.email == message.sender{
            mCell.containerView.backgroundColor = .systemOrange
        }else{
            mCell.containerView.backgroundColor = .systemBlue
        }
        
        mCell.senderNameLabel.text = message.sender
        mCell.messageLabel.text = message.message
        return mCell
    }
    
    
}
