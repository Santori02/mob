import Foundation

struct MessageEntity {
    let sender: String
    let message: String
}
